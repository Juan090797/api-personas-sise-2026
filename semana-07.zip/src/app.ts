
import express from 'express';
import personaRoutes from './routes/persona.routes';

const app = express();

const PORT = 3003;

//midleware que permite recibir datos en formato JSON en las solicitudes HTTP
app.use(express.json());

app.use('/personas', personaRoutes);


app.listen(PORT, () => {
    console.log(`Servidor escuchando en el puerto ${PORT}`);
});